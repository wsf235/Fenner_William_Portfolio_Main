/**
 * Created by MasterAnseen on 9/20/17.
 */
import React, { Component } from 'react'
import Button from '../components/Button'
//import FaArrowCircleORight from 'react-icons/lib/fa/arrow-circle-o-right'
import FaSearch from 'react-icons/lib/fa/search'

const styles={
    fontSize: '2em',
    margin: '0'
};

class Search extends Component {
    render() {
        return (
            <div className="">
                <p>
                    <input type="text" id="search" placeholder="Search" onKeyUp={ (event) => this.setSearch(event) }></input>
                    <Button label={<FaSearch style={styles}/>} />
                </p>
            </div>
        );
    }
}

export default Search