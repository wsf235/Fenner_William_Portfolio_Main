/**
 * Created by MasterAnseen on 9/20/17.
 */
import React, { Component } from 'react'

var user = JSON.parse(localStorage.getItem('Users'));

class PG3 extends Component{

    constructor(props){
        super(props);

        this.state = {
            user: user[0].name,
            post: user[0].post_count
        };
    }

    render(){
        return(
            <section className="">
                <h2>Username: {this.state.user}</h2>
                <h2>Post Count: {this.state.post}</h2>
                
        </section>
    );
    }
}

export default PG3