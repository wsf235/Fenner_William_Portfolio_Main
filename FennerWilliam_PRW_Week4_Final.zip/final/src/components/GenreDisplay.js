/**
 * Created by MasterAnseen on 9/21/17.
 */
import React, { Component } from 'react'
import Action from './genres/action'
import Adventure from './genres/adventure'
import Fighting from './genres/fighting'
import FPS from './genres/FPS'
import Horror from './genres/horror'
import Metroidvania from './genres/metroidvania'
import Platformer from './genres/platformer'
import RPG from './genres/RPG'
import Sports from './genres/sports'
import Strategy from './genres/strategy'
import Survival from './genres/survival'
import None from './genres/none'

import {
    BrowserRouter as Router,
    Route,
    Link
} from 'react-router-dom'

const styles={
    exDisplay:{
        width: '40%',
        float: 'left',
        paddingTop: '2em',
        paddingLeft: '2em',
        display: 'grid',
        gridGap: '20px',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))'
    }
};




class GenreDisplay extends Component {

    
    
    render() {
        return (
            <section className="">
                <Route exact path='/pg2' component={None} />
                <Route path='/pg2/Action' component={Action} />
                <Route path='/pg2/Adventure' component={Adventure} />
                <Route path='/pg2/Fighting' component={Fighting} />
                <Route path='/pg2/FPS' component={FPS} />
                <Route path='/pg2/Horror' component={Horror} />
                <Route path='/pg2/Metroidvania' component={Metroidvania} />
                <Route path='/pg2/Platformer' component={Platformer} />
                <Route path='/pg2/RPG' component={RPG} />
                <Route path='/pg2/Sports' component={Sports} />
                <Route path='/pg2/Strategy' component={Strategy} />
                <Route path='/pg2/Survival' component={Survival} />
            </section>
        );
    }
}
export default GenreDisplay