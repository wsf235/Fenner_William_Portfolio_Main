<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 10/29/17
 * Time: 9:32 AM
 */

class next_step extends app_controller{

    public function __construct()
    {

        $nav = $this->get_model();

        /*
                $this->get_view("header", array("pagename"=>"welcome"));
                $this->get_view("welcome");
                $this->get_view("navigation", $nav);

                if(!isset($_REQUEST["page"])){
                    $this->get_view("first");
                }
                elseif($_REQUEST["page"]==1){
                    $this->get_view("first");
                }
                elseif($_REQUEST["page"]==2){
                    $this->get_view("second");
                }
                elseif($_REQUEST["page"]==3){
                    $this->get_view("final");
                }
                else{
                    $this->get_view("first");
                }

                $this->get_view("footer");*/

    }

    public function index(){
        $nav = $this->get_model();


        $this->get_view("header", array("pagename"=>"welcome"));
        $this->get_view("welcome");
        $this->get_view("navigation", $nav);

        if(!isset($_REQUEST["page"])){
            $this->get_view("first");
        }
        elseif($_REQUEST["page"]==1){
            $this->get_view("first");
        }
        elseif($_REQUEST["page"]==2){
            $this->get_view("second");
        }
        elseif($_REQUEST["page"]==3){
            $this->get_view("final");
        }
        else{
            $this->get_view("first");
        }

        $this->get_view("form");

        $this->get_view("footer");
    }

    public function contact(){
        $nav = $this->get_model();

        $this->get_view("header", array("pagename"=>"welcome"));
        $this->get_view("navigation", $nav);
        $this->get_view("form");
    }

    public function contact_received(){
        $nav = $this->get_model();

        $this->get_view("header");
        $this->get_view("navigation", $nav);
        $this->get_view("form");

        var_dump($_POST);
        if(!preg_match("/^[a-zA-Z0-9]*$/", $_POST["user"])){
            echo "No special characters";
        }
        elseif(!preg_match("/^[a-zA-Z0-9]*$/", $_POST["pass"])){
            echo "No special characters";
        }
        elseif(!preg_match("/^[a-zA-Z0-9]*$/", $_POST["statement"])){
            echo "No special characters";
        }
        else{
            $this->get_view("success", $_POST);
        }
    }

    public function success()
    {
        $nav = $this->get_model();

        $this->get_view("header");
        $this->get_view("navigation", $nav);
        $this->get_view("success", $_POST);
        $this->get_view("footer");

    }

    public function ajax_par(){
        $this->get_view("ajax_par", $_REQUEST);

    }


}


?>