/**
 * Created by MasterAnseen on 9/20/17.
 */
import React, { Component } from 'react'

const styles={
    exObj:{
        margin: '15px',
        padding: '10px',
        width: '250px',
        height: '300px',
        float: 'left',
        backgroundColor: 'rgba(71,76,85,0.4)',
        backgroundImage: 'url("")',
        borderRadius: '5%',
        display: 'flex',
        flexDirection: 'column'
    }
};

if (!Date.prototype.toShortDate) {
    Date.prototype.toShortDate = function() {
        return this.getFullYear()
            +'-'
            +('0'+ (this.getMonth()+1)).slice(-2)
            + '-'
            + ('0'+ this.getDate()).slice(-2);
    }
}

function Data_Check() {
    //Uncomment if testing new code
    //localStorage.clear();
    var array = [];
    if(!localStorage.data_set) {
        localStorage.data_set = true;
        var _new = new Topic(
            "Initial Post",
            "Initial Post",
            "Moderator",
            "Action"
        );
        array.push(_new);

        console.log("Data created");
        localStorage.setItem('Topic_List', JSON.stringify(array));

        var user = [{"name":"8915razer", "post_count":"0"}];

        localStorage.setItem('Users', JSON.stringify(user));

    }
}


var topics = JSON.parse(localStorage.getItem('Topic_List'));

class Topic{
    constructor(a, b, c, d){
        this.title = a;
        this._text = b;
        this.views = 0;
        this.poster = c;
        this.genre = d;
    }
}


class PG1 extends Component{
    constructor(props){
        super(props);

        this.state = {
            topic_list: topics
        }
    }

    show_item(i){

        return <article style={styles.exObj}>
            <h2>{this.state.topic_list[i].title}</h2>
            <h3>{topics[i].poster}</h3>
            <p>{topics[i].genre}</p>
            <p>{topics[i]._text}</p>
            <p>{topics[i].views}</p>
        </article>
    }
    /*
    delete_symbol(){
        var delete_button = document.getElementsByClassName('remove');
        for(var o = 0; o < delete_button.length; o++){
            delete_button[o].addEventListener('click', function(e){
                e.preventDefault();
                console.log(e);

                var rekt = e.target.parentNode.parentNode;
                var spot = Array.from(e.target.parentNode.parentNode.parentNode.children).indexOf(rekt);

                console.log(rekt);

                e.target.parentNode.parentNode.parentNode.removeChild(rekt);
                Delete(spot);
            }
        }

    Delete(id){
        var count = JSON.parse(localStorage.getItem('Topic_List'));
        count.splice(id, 1);
        localStorage.setItem('Topic_List', JSON.stringify(count));
    }
    */
    show_list(){
        var obj = [];

        for(var i = 0; i < this.state.topic_list.length; i++){
            obj.push(this.show_item(i));
        }

        return obj;
    }


    render(){

        Data_Check();

        return(
            <section className="_Topic">
                {this.show_list()}
            </section>
        );
    }
}

export default PG1