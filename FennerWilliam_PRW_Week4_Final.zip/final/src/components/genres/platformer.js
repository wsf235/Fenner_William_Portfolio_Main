/**
 * Created by MasterAnseen on 9/21/17.
 */
import React, { Component } from 'react'


const styles={
    exObj:{
        width: '250px',
        height: '300px',
        float: 'left',
        backgroundColor: 'rgba(71,76,85,0.4)',
        borderRadius: '5%',
        display: 'flex',
        flexDirection: 'column'
    }
};


class Platformer extends Component {
    constructor(props){
        super(props);
        //You should set the state here
        this.state = {
            trending:[]
        }
    }
    render() {
        return (
            <article style={styles.exObj}>
                <p>Platformer</p>
                <p>Platform games (or platformers) are set in a vertically exaggerated environment. Players navigate their environment by jumping and climbing on platforms, while avoiding obstacles and battling enemies in order to advance. They often involve unrealistic physics and special movement abilities.</p>
            </article>
        )
    }
}
export default Platformer