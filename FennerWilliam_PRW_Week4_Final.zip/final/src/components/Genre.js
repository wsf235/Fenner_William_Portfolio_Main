/**
 * Created by MasterAnseen on 9/21/17.
 */
import React, { Component } from 'react'
//React Router
import { NavLink } from 'react-router-dom'


const styles={
    exLinks:{
        paddingTop: '2.5em',
        listStyle: 'none',
        marginLeft: '-3em',
        fontSize: '0.75em',
        fontWeight:'bolder'
    },
    myli:{
        paddingBottom: '0.3em'
    },
    exCont:{
        width: '40%',
        float: 'left'
    }
};


class GenreList extends Component {
    render() {
        return (
            <nav style={styles.exCont}>
                <ul className="exLinks3" style={styles.exLinks}>
                    <li style={styles.myli}><NavLink to="/pg2/Action">Action</NavLink></li>
                    <li style={styles.myli}><NavLink to="/pg2/Platformer">Platformer</NavLink></li>
                    <li style={styles.myli}><NavLink to="/pg2/FPS">FPS</NavLink></li>
                    <li style={styles.myli}><NavLink to="/pg2/Fighting">Fighting</NavLink></li>
                    <li style={styles.myli}><NavLink to="/pg2/Survival">Survival</NavLink></li>
                    <li style={styles.myli}><NavLink to="/pg2/Horror">Horror</NavLink></li>
                    <li style={styles.myli}><NavLink to="/pg2/Metroidvania">Metroidvania</NavLink></li>
                    <li style={styles.myli}><NavLink to="/pg2/Adventure">Adventure</NavLink></li>
                    <li style={styles.myli}><NavLink to="/pg2/RPG">RPG</NavLink></li>
                    <li style={styles.myli}><NavLink to="/pg2/Strategy">Strategy</NavLink></li>
                    <li style={styles.myli}><NavLink to="/pg2/Sports">Sports</NavLink></li>
                </ul>
            </nav>
        )
    }
}
export default GenreList
