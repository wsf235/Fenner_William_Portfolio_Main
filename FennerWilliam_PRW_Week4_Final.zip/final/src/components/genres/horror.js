/**
 * Created by MasterAnseen on 9/21/17.
 */
import React, { Component } from 'react'


const styles={
    exObj:{
        width: '250px',
        height: '300px',
        float: 'left',
        backgroundColor: 'rgba(71,76,85,0.4)',
        borderRadius: '5%',
        display: 'flex',
        flexDirection: 'column'
    }
};


class Horror extends Component {
    constructor(props){
        super(props);
        //You should set the state here
        this.state = {
            trending:[]
        }
    }
    render() {
        return (
            <article style={styles.exObj}>
                <p>Horror</p>
                <p>Horror games focus on fear and attempt to scare the player via traditional horror fiction elements such as atmospherics, death, the undead, blood and gore. One crucial gameplay element in many of these games is the low quantity of ammunition, or number of breakable melee weapons.</p>
            </article>
        )
    }
}
export default Horror