/**
 * Created by MasterAnseen on 8/28/17.
 */




window.addEventListener("load", function(){

    $.ajax({
        url: "https://api.myjson.com/bins/f4ayd",
        dataType: "json",
        success: function( result ) {
            //localStorage.clear();
            var recipe_array = [];
            if(!localStorage.data_set) {
                localStorage.data_set = true;
                for (var i = 0; i < result.recipes.length; i++) {
                    var _new = new Recipe(
                        result.recipes[i].recipeID,
                        result.recipes[i].title,
                        result.recipes[i].description,
                        result.recipes[i].category,
                        result.recipes[i].starRating,
                        result.recipes[i].photoUrl
                    );
                    recipe_array.push(_new);
                }
                console.log("Data created");
                localStorage.setItem('recipe_list', JSON.stringify(recipe_array));
            }
            localStorage.setItem('item', result.recipes[1].title);
        }
    });

    console.log("Window created");

    Utility.Display();


    //$( '#add' ).click(function () {
    //    $( '#modal' ).active = true;
    //});
    document.querySelector('#add').addEventListener('click', function(){
        document.getElementById("modal").active = true;
    });

    var e_count = JSON.parse(localStorage.getItem('recipe_list'));
    for(var m = 0; m < e_count.length; m++) {
        document.querySelector('#edit'+m).addEventListener('click', function () {
            document.getElementById("edit_modal").active = true;
            document.getElementById("edit_title").value = e_count[m].title;
            document.getElementById("edit_desc").value = e_count[m].description;
            document.getElementById("edit_category").value = e_count[m].category;
            document.getElementById("edit_rating").value = e_count[m].rating;
            document.getElementById("edit_img").value = e_count[m].img;
        });
    }

    document.querySelector("#new_recipe").addEventListener('click', function(e){
        e.preventDefault();

        Utility.Add();
        Utility.Display();
    });

    var e_count = JSON.parse(localStorage.getItem('recipe_list'));
    for(var m = 0; m < e_count.length; m++) {
        document.querySelector('#edit_recipe').addEventListener('click', function (e) {
            e.preventDefault();

            var l = document.getElementById('edit' + (m-1) + '').id;
            l.splice(0,4);
            Utility.Edit(l);
            Utility.Display();
        });
    }

    var d_count = JSON.parse(localStorage.getItem('recipe_list'));
    for(var r = 0; r < d_count.length; r++) {
        document.getElementById('remove'+r+'').addEventListener('click', function (e) {
            e.preventDefault();
            console.log(document.getElementById('remove' + (r-1) + '').id);
            var l = document.getElementById('remove'+(r-1)+'').id;
            l.splice(0,6);
            Utility.Delete(l);
            Utility.Display();
        })
    }

});





class Utility{
    constructor(){

    }
    static Display(){
        document.getElementById("menu_list").innerHTML = "";
        var list = JSON.parse(localStorage.getItem('recipe_list'));
        for(var k = 0; k < list.length; k++) {

            document.getElementById("menu_list").innerHTML += "<div id='menu_item'>"
                + "<img src='" + list[k].img + "'> <br />"
                + "<h2>" + list[k].title + "</h2> <br />"
                + "<p>" + list[k].description + "</p> <br />"
                + "<p>" + list[k].category + "</p> <br />"
                + "<p>Star Rating: " + list[k].rating + "</p>"
                + "<button id='remove"+k+"'>Remove</button>"
                + "<button id='edit"+k+"'>Edit</button>"
                + "</div>";
        }
    }

    static Add(){
        var count = JSON.parse(localStorage.getItem('recipe_list'));
        var add_new = new Recipe(
            count.length,
            document.getElementById("title").value,
            document.getElementById("desc").value,
            document.getElementById("category").value,
            document.getElementById("rating").value,
            document.getElementById("_img").value
        );
        count.push(add_new);
        console.log(count);
        localStorage.setItem('recipe_list', JSON.stringify(count));
        //document.querySelector("form").clear();
        document.getElementById("modal").active = false;

    }

    static Delete(item){
        var count = JSON.parse(localStorage.getItem('recipe_list'));
        count.splice(item);
        localStorage.setItem('recipe_list', JSON.stringify(count));
    }

    static Edit(item){
        var count = JSON.parse(localStorage.getItem('recipe_list'));
        var add_update = new Recipe(
            count.length,
            document.getElementById("edit_title").value,
            document.getElementById("edit_desc").value,
            document.getElementById("edit_category").value,
            document.getElementById("edit_rating").value,
            document.getElementById("edit_img").value
        );
        count[item] = add_update;
        console.log(count);
        localStorage.setItem('recipe_list', JSON.stringify(count));
        //document.querySelector("form").clear();
        document.getElementById("modal").active = false;
    }
}

//create a data object for recipes
class Recipe{
    constructor(a, b, c, d, e, f){
        this.ID = a;
        this.title = b;
        this.description = c;
        this.category = d;
        this.rating = e;
        this.img = f;
    }
}