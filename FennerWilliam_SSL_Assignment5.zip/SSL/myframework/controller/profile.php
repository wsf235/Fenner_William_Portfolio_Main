<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 11/3/17
 * Time: 12:02 AM
 */

class profile extends app_controller{

    public function __construct()
    {

        if(@$_SESSION["logged_in"] && $_SESSION["logged_in"] == 1){

        }else{
            header("Location:/next_step");
        }

    }

    public function index(){
        $nav = $this->get_model();
        $this->get_view("header");
        $this->get_view("navigation", $nav);

        $this->get_view("profile");

    }

}


?>