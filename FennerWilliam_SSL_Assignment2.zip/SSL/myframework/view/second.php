</header>
<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 10/29/17
 * Time: 8:31 PM
 */

?>


<p>second page</p>

<img src="https://i1.wp.com/www.bumped.org/psublog/wp-content/uploads/2015/12/PSO2-Episode-4-Visual.jpg">