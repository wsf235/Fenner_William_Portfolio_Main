<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 10/29/17
 * Time: 9:38 PM
 */?>


<footer>
    <p>footer stuff</p>
</footer>
