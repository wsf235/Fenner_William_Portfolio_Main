/**
 * Created by MasterAnseen on 9/21/17.
 */
import React, { Component } from 'react'


const styles={
    exObj:{
        width: '250px',
        height: '300px',
        float: 'left',
        backgroundColor: 'rgba(71,76,85,0.4)',
        borderRadius: '5%',
        display: 'flex',
        flexDirection: 'column'
    }
};


class Fighting extends Component {
    constructor(props){
        super(props);
        //You should set the state here
        this.state = {
            trending:[]
        }
    }
    render() {
        return (
            <article style={styles.exObj}>
                <p>Fighting</p>
                <p>Fighting games simulate close-range combat against a few opponents, often involving violent and exaggerated unarmed attacks against opponents. While ranged and melee weapons may be present in fighting games, they emphasize hand-to-hand combat.</p>
            </article>
        )
    }
}
export default Fighting