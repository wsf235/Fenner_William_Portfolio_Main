/**
 * Created by MasterAnseen on 9/21/17.
 */
import React, { Component } from 'react'

import Modal from 'react-modal'

const customStyles = {
    overlay : {
        position          : 'fixed',
        top               : 0,
        left              : 0,
        right             : 0,
        bottom            : 0,
        backgroundColor   : 'rgba(255, 255, 255, 0.75)'
    },
    content : {
        top                   : '50%',
        left                  : '50%',
        right                 : 'auto',
        bottom                : 'auto',
        marginRight           : '-50%',
        transform             : 'translate(-50%, -50%)'
    }
};

class Topic{
    constructor(a, b, c, d){
        this.title = a;
        this._text = b;
        this.views = 0;
        this.poster = c;
        this.genre = d;
    }
}

class Message extends Component {
    constructor(props) {
        super(props);

        this.state = {
            open: false,
            get_title: "",
            get_text: "",
            get_array: JSON.parse(localStorage.getItem('Topic_List')),
            get_user: JSON.parse(localStorage.getItem('Users'))
        };

        this.openModal = this.openModal.bind(this);
        this.afterOpenModal = this.afterOpenModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
    }

    openModal() {
        this.setState({open: true})
    }

    afterOpenModal() {
        // references are now sync'd and can be accessed.
        this.subtitle.style.color = '#f00'
    }

    closeModal() {

        this.setState({
            get_title: document.getElementById('title').value,
            get_text: document.getElementById('_text').value
        });
        this.setState({open: false});

        var _new = new Topic(
            document.getElementById('title').value,
            document.getElementById('_text').value,
            this.state.get_user[0].name,
            document.getElementById('category').value
        );
        this.state.get_array.push(_new);

        this.state.get_user.post_count = Number(this.state.get_user.post_count) + 1;
        localStorage.setItem('Users', JSON.stringify(this.state.get_user));
        localStorage.setItem('Topic_List', JSON.stringify(this.state.get_array));
        console.log(localStorage.getItem('Topic_List'));
        window.location.reload(false);
    }

    exitModal(){
        this.setState({open: false});
    }

    render() {
        return (
            <section className="">
                <button onClick={this.openModal}>Send Message</button>
                <Modal
                    isOpen={this.state.open}
                    onAfterOpen={this.afterOpenModal}
                    onRequestClose={this.closeModal}
                    style={customStyles}
                    contentLabel="Post a new topic"
                >

                    <h2 ref={subtitle => this.subtitle = subtitle}>Start a new topic!</h2>

                    <form>
                        <label>Topic Title</label>
                        <input type="text" id="title" />
                        <label>Discussion</label>
                        <input type="text" id="_text" />
                        <select id="category">
                            <option value="Action">Action</option>
                            <option value="Adventure">Adventure</option>
                            <option value="Fighting">Fighting</option>
                            <option value="FPS">FPS</option>
                            <option value="Horror">Horror</option>
                            <option value="Metroidvania">Metroidvania</option>
                            <option value="Platformer">Platformer</option>
                            <option value="RPG">RPG</option>
                            <option value="Sports">Sports</option>
                            <option value="Strategy">Strategy</option>
                            <option value="Survival">Survival</option>
                        </select>
                    </form>
                    <button onClick={this.closeModal}>Submit</button>
                    <button onClick={this.exitModal}>Cancel</button>
                </Modal>
            </section>
        )
    }
}

export default Message