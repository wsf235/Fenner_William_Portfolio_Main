<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 11/13/17
 * Time: 5:29 PM
 */

?>



<div class="container">
    <form method="post" action="/api/search">
        <h2>Search for books</h2>
        <input type="text" name="search_item" placeholder="Search" />
        <input type="submit" value="Go!" />
    </form>
</div>



