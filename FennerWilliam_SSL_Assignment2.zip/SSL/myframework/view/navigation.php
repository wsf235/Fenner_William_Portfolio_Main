
<nav>
<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 10/29/17
 * Time: 12:49 PM
 */

echo '<li><a href="?page=1" >'.$data["page1"].'</a></li>'.
'<li><a href="?page=2" >'.$data["page2"].'</a></li>'.
'<li><a href="?page=3" >'.$data["page3"].'</a></li>' ;

?>

</nav>
