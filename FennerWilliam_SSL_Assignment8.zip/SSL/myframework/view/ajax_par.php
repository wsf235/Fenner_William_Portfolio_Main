<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 11/2/17
 * Time: 10:22 PM
 */

var_dump($_REQUEST);
if($_REQUEST["user"] == "Orenglaive"){
    echo "Yo!";
}else{
    echo "go away";
}
?>