<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 11/4/17
 * Time: 2:47 PM
 */

class auth extends app_controller{

    public function __construct()
    {



    }

    //auth/login
    public function login(){

        if($_REQUEST['email'] && $_REQUEST["password"]){

            /*if($_REQUEST['email']==$_SESSION["admin_email"] && $_REQUEST["password"]==$_SESSION["admin_pass"]) {
                $_SESSION["logged_in"]=1;
                $_SESSION["email"] = $_SESSION["admin_email"];
                header("Location:/next_step");
            }elseif($_SESSION['email']==$_REQUEST["email"] && $_SESSION["pass"]==$_REQUEST["password"]) {
                $_SESSION["logged_in"]=1;
                $_SESSION["email"] = $_REQUEST["email"];
                header("Location:/next_step");
            }else{
                header("Location:/next_step?msg=Bad_Login_Type1");
            }*/

            if(array_key_exists($_REQUEST['email'], $GLOBALS["userbase"])){
                if(in_array($_REQUEST['password'], $GLOBALS["userbase"][$_REQUEST['email']])) {
                    $_SESSION["logged_in"] = 1;
                    $_SESSION['current_user'] = $GLOBALS["userbase"][$_REQUEST['email']];
                    header("Location:/next_step");
                }else{
                    header("Location:/next_step?msg=Bad Login, password not found or incorrect.");
                }
            }else{
                header("Location:/next_step?msg=Bad Login, username not found or incorrect");
            }

        }else{
            header("Location:/next_step?msg=Bad_Login_Type2");
        }
    }

    public function logout(){
        session_destroy();
        header("Location:/next_step");
    }


}


?>