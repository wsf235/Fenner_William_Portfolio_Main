<?php
/**
 * Created by PhpStorm.
 * User: William Fenner
 * Date: 10/27/17
 * Time: 9:52 PM
 */
//Part 1
include "bin/config.php";


?>