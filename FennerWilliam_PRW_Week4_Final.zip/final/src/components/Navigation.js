/**
 * Created by MasterAnseen on 9/20/17.
 */
import React, { Component } from 'react'
import { NavLink } from 'react-router-dom'

import PG1 from '../pages/pg1'
import PG2 from '../pages/pg2'
import PG3 from '../pages/pg3'
import Message from './Messages'

import FaHome from 'react-icons/lib/ti/home-outline'
import FaSearch from 'react-icons/lib/fa/search'
import FaHeart from 'react-icons/lib/fa/heart'

class Navigation extends Component{
    render(){
        return(
            <nav className="">
                <NavLink to="/pg1"><FaHome />Home</NavLink>
                <NavLink to="/pg2"><FaSearch />Search</NavLink>
                <NavLink to="/pg3"><FaHeart />Profile</NavLink>
                <Message />
            </nav>
        );
    }
}

export default Navigation