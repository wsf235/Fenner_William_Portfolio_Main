/**
 * Created by MasterAnseen on 9/21/17.
 */
import React, { Component } from 'react'


const styles={
    exObj:{
        width: '250px',
        height: '300px',
        float: 'left',
        backgroundColor: 'rgba(71,76,85,0.4)',
        borderRadius: '5%',
        display: 'flex',
        flexDirection: 'column'
    }
};


class Strategy extends Component {
    constructor(props){
        super(props);
        //You should set the state here
        this.state = {
            trending:[]
        }
    }
    render() {
        return (
            <article style={styles.exObj}>
                <p>Strategy</p>
                <p>Strategy video games focus on gameplay requiring careful and skillful thinking and planning in order to achieve victory and the action scales from world domination to squad-based tactics.</p>
            </article>
        )
    }
}
export default Strategy