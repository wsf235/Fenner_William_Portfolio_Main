/**
 * Created by MasterAnseen on 9/20/17.
 */
import React, { Component } from 'react'
import Navigation from './Navigation'
import Search from './Search'

class Header extends Component{
    render(){
        return(
            <header className="header">
                <h1>Gametrest</h1>
                <Search />
                <Navigation />
            </header>
        );
    }
}

export default Header