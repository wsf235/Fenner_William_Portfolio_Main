const path = require('path');
const webpack = require('webpack');

module.exports = {
    entry: './main.js',
    output: {
        filename: '../../dist/js/bundle.js'//,
        //path: path.resolve(__dirname, 'dist')
    }
};

new webpack.DefinePlugin({
    'process.env': {
        NODE_ENV: JSON.stringify('production')
    }
});
    new webpack.optimize.UglifyJsPlugin();