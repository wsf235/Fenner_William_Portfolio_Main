/**
 * Created by MasterAnseen on 9/21/17.
 */
import React, { Component } from 'react'


const styles={
    exObj:{
        width: '250px',
        height: '300px',
        float: 'left',
        backgroundColor: 'rgba(71,76,85,0.4)',
        borderRadius: '5%',
        display: 'flex',
        flexDirection: 'column'
    }
};


class Action extends Component {
    render() {
        return (
            <article style={styles.exObj}>
                <p>Action</p>
                <p>Action games emphasize physical challenges that require eye-hand coordination and motor skill to overcome. They center around the player, who is in control of most of the action.</p>
            </article>
        )
    }
}

export default Action