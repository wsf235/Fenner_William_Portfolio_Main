<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 11/9/17
 * Time: 3:16 PM
 */

?>


<div class="container">
    <h1>Add a fruit</h1>
    <form action="/about/add_action" method="post">
        <input type="text" name="name" placeholder="Bananas ?"/>
        <input type="submit" />
    </form>
</div>




