<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 11/5/17
 * Time: 8:53 PM
 */


echo '<b>'.$_SESSION["user"].'</b><br />';
echo '<b>'.$_SESSION["statement"].'</b>';



?>