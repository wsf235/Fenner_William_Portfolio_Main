<h1>Congratulations!</h1>

<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 11/2/17
 * Time: 11:00 PM
 */

echo '<p style="color: #1c7430">'.$_POST["email"].'</p><br />'.
    '<p style="color: #1c7430">'.$_POST["pass"].'</p><br />'.
    '<p style="color: #1c7430">'.$_POST["check"].'</p><br />'.
    '<p style="color: #1c7430">'.$_POST["statement"].'</p>';


?>