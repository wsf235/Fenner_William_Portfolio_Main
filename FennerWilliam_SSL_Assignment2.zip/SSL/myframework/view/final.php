</header>
<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 10/29/17
 * Time: 8:31 PM
 */


?>

<p>final page</p>


<img src="https://static.giantbomb.com/uploads/original/2/26008/855576-touhoubg.jpg">