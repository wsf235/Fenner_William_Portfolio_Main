/**
 * Created by MasterAnseen on 9/20/17.
 */
import React, { Component } from 'react'

const styles={
    btn:{
        background: 'none',
        border: 'none',
        padding: '.40em',
        color: 'rgb(255,86,96)',
        fontSize: '0.65em'
    }
};


class Button extends Component {
    render() {
        return (
            <button style={styles.btn} onClick={this.props.handleClick}>
                {this.props.label}
            </button>
        );
    }
}

export default Button