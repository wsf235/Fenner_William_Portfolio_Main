/**
 * Created by MasterAnseen on 9/21/17.
 */
import React, { Component } from 'react'


const styles={
    exObj:{
        width: '250px',
        height: '300px',
        float: 'left',
        backgroundColor: 'rgba(71,76,85,0.4)',
        borderRadius: '5%',
        display: 'flex',
        flexDirection: 'column'
    }
};


class Metroidvania extends Component {
    constructor(props){
        super(props);
        //You should set the state here
        this.state = {
            trending:[]
        }
    }
    render() {
        return (
            <article style={styles.exObj}>
                <p>Metroidvania</p>
                <p>Metroidvania games feature a large interconnected world map the player can explore, but access to parts of the world is limited by doors or other obstacles that can only be opened after the player has acquired special tools, weapons or abilities within the game.</p>
            </article>
        )
    }
}
export default Metroidvania