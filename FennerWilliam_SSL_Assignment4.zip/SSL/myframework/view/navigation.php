



<nav class="navbar navbar-expand-lg navbar-light bg-dark">
    <a class="navbar-brand" href="/next_step">Hello World!</a>
    <div class="progress">
        <div class="progress-bar" role="progressbar" style="width:<?php echo $_REQUEST["page"]*33 ?>" aria-valuenow=<?php echo rand(1, 100); ?> aria-valuemin="0" aria-valuemax="100"></div>
    </div>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <?php
            /**
             * Created by PhpStorm.
             * User: MasterAnseen
             * Date: 10/29/17
             * Time: 12:49 PM
             */

            echo '<li class="nav-item active"><a class="nav-link" href="?page=1" ><button>'.$data["page1"].'</button></a></li>'.
                '<li class="nav-item"><a class="nav-link" href="?page=2" ><button>'.$data["page2"].'</button></a></li>'.
                '<li class="nav-item"><a class="nav-link" href="?page=3" ><button>'.$data["page3"].'</button></a></li>';
            ?>
        </ul>
    </div>
</nav>
