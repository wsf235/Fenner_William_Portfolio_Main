/**
 * Created by MasterAnseen on 9/9/17.
 */
import _ from "lodash";
import React from 'react';
import ReactDOM from 'react-dom';

const RE = React.createElement;

class Hello extends React.Component {
    render() {
        return React.createElement('p', null, `${this.props.toWhat}`);
    }
}

ReactDOM.render(
    RE(Hello, {toWhat: 'Built by William Fenner for the Programming for Web Applications class'}, null),
    document.getElementById('end')
);

if (!Date.prototype.toShortDate) {
    Date.prototype.toShortDate = function() {
        return this.getFullYear()
            +'-' 
            +('0'+ (this.getMonth()+1)).slice(-2)
            + '-'
            + ('0'+ this.getDate()).slice(-2);
    }
}




function Data_Check(array) {

    //Uncomment if testing new code
    //localStorage.clear();
    var array = [];
    if(!localStorage.data_set) {
        localStorage.data_set = true;
        var _new = new Transaction(
            0,
            "Initial Deposit",
            5000,
            new Date().toShortDate(),
            false
        );
        array.push(_new);

        console.log("Data created");
        localStorage.setItem('bank_transactions', JSON.stringify(array));
    }
    return array;
}




window.addEventListener("load", function(){

    var bank = [];
    Data_Check(bank);

    console.log("Window created");

    Utility.Display();


    document.querySelector('#open').addEventListener('click', function(){
        document.getElementById("modal").active = true;
    });

    document.querySelector('#submit').addEventListener('click', function(e){
        e.preventDefault();

        var w = document.getElementById("name").value;
        var x = document.getElementById("amount").value;
        var y = document.getElementById("date").value;
        var z = document.getElementById("pending").value;

        if(w === ""){
            alert("Transaction Name: Please enter a title");
        }
        else if(isNaN(x)){
            alert("Amount: Numbers only please");
        }
        else{
            Utility.Add();
            Utility.Display();
        }

    });
});





class Utility{
    constructor(){

    }
    static Display(){
        document.getElementById("root").innerHTML = "";
        var list = JSON.parse(localStorage.getItem('bank_transactions'));

        for(var k = 0; k < list.length; k++) {

            document.getElementById("root").innerHTML += "<tr id='menu_item'>"
                + "<td>" + list[k].title + "</td>"
                + "<td>" + list[k].amount + "</td>"
                + "<td>" + list[k].date + "</td>"
                + "<td>" + list[k].pending + "</td>"
                + "<td class='remove'><img src='img/delete.png' alt='#' title='Remove Item'></td>"
                + "<td class='edit'><img src='img/update.png' alt='#' title='Edit Item'></td>"
                + "</tr>";
        }

        var delete_button = document.getElementsByClassName('remove');
        for(var o = 0; o < delete_button.length; o++){
            delete_button[o].addEventListener('click', function(e){
                e.preventDefault();
                console.log(e);

                var rekt = e.target.parentNode.parentNode;
                var spot = Array.from(e.target.parentNode.parentNode.parentNode.children).indexOf(rekt);

                console.log(rekt);

                e.target.parentNode.parentNode.parentNode.removeChild(rekt);
                Utility.Delete(spot);
                Utility.Adjust();
                Utility.Display();
            });
        }

        var edit_button = document.getElementsByClassName('edit');
        for(var o = 0; o < delete_button.length; o++){
            edit_button[o].addEventListener('click', function(e){
                e.preventDefault();
                console.log(e);
                var rekt = e.target.parentNode.parentNode;
                var spot = Array.from(e.target.parentNode.parentNode.parentNode.children).indexOf(rekt);

                document.getElementById("edit_modal").active = true;
                Utility.Load("edit_modal", spot);
                document.querySelector('#edit_submit').addEventListener('click', function(e){
                    e.preventDefault();

                    if(document.getElementById("_name").value === ""){
                        alert("Transaction Name: Please enter a title");
                    }
                    else if(isNaN(document.getElementById("_amount").value)){
                        alert("Amount: Numbers only please");
                    }
                    else {
                        Utility.Edit(spot);
                        Utility.Adjust();
                        Utility.Display();
                    }
                });
            });
        }
    }

    static Add(){

        if(!Date.parse(document.getElementById("date").value)){
            document.getElementById("date").value = new Date().toShortDate();
        }

        var count = JSON.parse(localStorage.getItem('bank_transactions'));
        var add_new = new Transaction(
            count.length,
            document.getElementById("name").value,
            document.getElementById("amount").value,
            document.getElementById("date").value,
            document.getElementById("pending").checked
        );
        count.push(add_new);
        console.log(count);
        localStorage.setItem('bank_transactions', JSON.stringify(count));
        document.querySelector("form").reset();
        document.getElementById("modal").active = false;

    }

    static Delete(id){
        var count = JSON.parse(localStorage.getItem('bank_transactions'));
        count.splice(id, 1);
        localStorage.setItem('bank_transactions', JSON.stringify(count));
    }

    static Edit(item){

        if(!Date.parse(document.getElementById("_date").value)){
            document.getElementById("_date").value = new Date().toShortDate();
        }

        var count = JSON.parse(localStorage.getItem('bank_transactions'));
        var add_edit = new Transaction(
            count.length,
            document.getElementById("_name").value,
            document.getElementById("_amount").value,
            document.getElementById("_date").value,
            document.getElementById("_pending").checked
        );
        count[item] = add_edit;
        console.log(count);
        localStorage.setItem('bank_transactions', JSON.stringify(count));
        document.querySelector("form").reset();
        document.getElementById("edit_modal").active = false;
    }

    static Adjust(){
        var bank_list = JSON.parse(localStorage.getItem('bank_transactions'));
        for(var i = 0; i < bank_list.length; i++){
            bank_list[i].ID = i;
        }
        localStorage.setItem('bank_transactions', JSON.stringify(bank_list));
    }

    static Load(version, val){
        var count = JSON.parse(localStorage.getItem('bank_transactions'));

        if(version == "modal"){
            document.getElementById("name").value = count[val].title;
            document.getElementById("amount").value = count[val].amount;
            document.getElementById("date").value = count[val].date;
            document.getElementById("pending").value = count[val].pending;
        }
        else{
            document.getElementById("_name").value = count[val].title;
            document.getElementById("_amount").value = count[val].amount;
            document.getElementById("_date").value = count[val].date;
            document.getElementById("_pending").value = count[val].pending;
        }
    }
}

//create a data object for bank history
class Transaction{
    constructor(a, b, c, d, e){
        this.ID = a;
        this.title = b;
        this.amount = c;
        this.date = d;
        this.pending = e;
    }
}