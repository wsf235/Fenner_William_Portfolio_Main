/**
 * Created by MasterAnseen on 9/20/17.
 */
import React, { Component } from 'react'

import {
    BrowserRouter as Router,
    Route,
    Link
} from 'react-router-dom'

import PG1 from '../pages/pg1'
import PG2 from '../pages/pg2'
import PG3 from '../pages/pg3'
import PG4 from '../pages/pg4'

class Main extends Component{
    render() {
        return(
            <section className="content main-content main">
                <Route path='/pg1' component={PG1} />
                <Route path='/pg2' component={PG2} />
                <Route path='/pg3' component={PG3} />
                <Route path='/pg4' component={PG4} />
            </section>
        );
    }
}

export default Main