/**
 * Created by MasterAnseen on 9/20/17.
 */
import React, { Component } from 'react'
import Genrelist from '../components/Genre'
import GenreDisplay from '../components/GenreDisplay'

class PG2 extends Component{
    render(){
        return(
            <section className="">
            <div>
                <h2>Gametrest Topics</h2>
                <p>View the verious topics of gaming by genre.</p>
            </div>
                <div>
                    <Genrelist />
                    <GenreDisplay />
                </div>
        </section>
    );
    }
}

export default PG2