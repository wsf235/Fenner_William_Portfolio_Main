/**
 * Created by MasterAnseen on 9/22/17.
 */
import React, { Component } from 'react'


const styles={
    exObj:{
        width: '250px',
        height: '300px',
        float: 'left',
        backgroundColor: 'rgba(71,76,85,0.4)',
        borderRadius: '5%',
        display: 'flex',
        flexDirection: 'column'
    }
};


class None extends Component {
    render() {
        return (
            <article style={styles.exObj}>
                <p>Click a genre to display its definition. (full search functionality not yet implemented)</p>
            </article>
        )
    }
}

export default None