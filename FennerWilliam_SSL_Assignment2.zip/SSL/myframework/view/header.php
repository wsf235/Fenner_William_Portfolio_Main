<head>
    <title>Hello World</title>
    <link rel="stylesheet" href="../styles.css">
</head>

<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 10/29/17
 * Time: 9:37 AM
 */

//var_dump($data);
?>

<header>
    Header stuff
