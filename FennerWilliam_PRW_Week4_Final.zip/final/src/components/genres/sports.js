/**
 * Created by MasterAnseen on 9/21/17.
 */
import React, { Component } from 'react'


const styles={
    exObj:{
        width: '250px',
        height: '300px',
        float: 'left',
        backgroundColor: 'rgba(71,76,85,0.4)',
        borderRadius: '5%',
        display: 'flex',
        flexDirection: 'column'
    }
};


class Sports extends Component {
    constructor(props){
        super(props);
        //You should set the state here
        this.state = {
            trending:[]
        }
    }
    render() {
        return (
            <article style={styles.exObj}>
                <p>Sports</p>
                <p>Sports games emulate the playing of traditional physical sports. Some emphasize actually playing the sport, while others emphasize the strategy behind the sport.</p>
            </article>
        )
    }
}
export default Sports