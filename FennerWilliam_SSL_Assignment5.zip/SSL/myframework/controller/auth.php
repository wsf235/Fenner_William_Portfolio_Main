<?php
/**
 * Created by PhpStorm.
 * User: MasterAnseen
 * Date: 11/4/17
 * Time: 2:47 PM
 */

class auth extends app_controller{

    public function __construct()
    {



    }

    //auth/login
    public function login(){

        if($_REQUEST['username'] && $_REQUEST["password"]){

            if($_REQUEST['username']==$_SESSION["admin_user"] && $_REQUEST["password"]==$_SESSION["admin_pass"]) {
                $_SESSION["logged_in"]=1;
                $_SESSION["user"] = $_SESSION["admin_user"];
                header("Location:/next_step");
            }elseif($_SESSION['user']==$_REQUEST["username"] && $_SESSION["pass"]==$_REQUEST["password"]) {
                $_SESSION["logged_in"]=1;
                $_SESSION["user"] = $_REQUEST["username"];
                header("Location:/next_step");
            }else{
                header("Location:/next_step?msg=Bad_Login_Type1");
            }

        }else{
            header("Location:/next_step?msg=Bad_Login_Type2");
        }
    }

    public function logout(){
        session_destroy();
        header("Location:/next_step");
    }


}


?>